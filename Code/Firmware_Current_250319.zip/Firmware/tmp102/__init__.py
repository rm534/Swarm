
from tmp102._tmp102 import Tmp102

del _tmp102
